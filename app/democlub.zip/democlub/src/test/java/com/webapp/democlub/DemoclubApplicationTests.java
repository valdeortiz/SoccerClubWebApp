package com.webapp.democlub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoclubApplicationTests {

	@Test
	void contextLoads() {
	}

}
