package com.webapp.democlub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoclubApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoclubApplication.class, args);
	}

}
